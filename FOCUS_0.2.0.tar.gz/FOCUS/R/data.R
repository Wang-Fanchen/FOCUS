#' Gene Location Reference Data
#'
#' A comprehensive dataset containing chromosomal location information for
#' human genes including cytoband positions, genomic coordinates, and gene aliases.
#'
#' @format A data frame with 206,757 rows and 8 columns:
#' \describe{
#'   \item{Symbol}{Official gene symbol (HGNC)}
#'   \item{Aliases}{Alternative gene names and aliases, semicolon-separated}
#'   \item{Cytoband}{Chromosomal cytoband location (e.g., "17p13.1")}
#'   \item{chromosome}{Chromosome number (1-22, X, Y)}
#'   \item{start_position_on_the_genomic_accession}{Genomic start position (hg38)}
#'   \item{end_position_on_the_genomic_accession}{Genomic end position (hg38)}
#'   \item{orientation}{Gene orientation: "+" for forward, "-" for reverse}
#'   \item{exon_count}{Number of exons in the gene}
#' }
#' @source NCBI Gene database, downloaded and processed from
#'   \url{https://www.ncbi.nlm.nih.gov/gene}
#'
#' @details
#' This dataset provides essential chromosomal location information for
#' human genes and is used throughout the FOCUS package for:
#' \itemize{
#'   \item Matching genes to their chromosomal locations
#'   \item Creating chromosome ideograms
#'   \item Performing cytoband-level attribution analysis
#'   \item Supporting both symbol and alias gene name matching
#' }
#'
#' The genomic coordinates are based on the GRCh38/hg38 human genome assembly.
#' Cytoband information follows the standard ISCN (International System for
#' Human Cytogenomic Nomenclature) format.
#'
#' @examples
#' \dontrun{
#' # Load the gene location data
#' data(gene_location)
#'
#' # View basic information
#' head(gene_location)
#' dim(gene_location)
#'
#' # Search for specific genes
#' tp53_info <- gene_location[gene_location$Symbol == "TP53", ]
#' brca_aliases <- gene_location[grepl("BRCA", gene_location$Aliases), ]
#'
#' # Count genes by chromosome
#' chr_counts <- table(gene_location$chromosome)
#'
#' # Genes on chromosome 17
#' chr17_genes <- gene_location[gene_location$chromosome == "17", ]
#' }
#' @keywords datasets
"gene_location"